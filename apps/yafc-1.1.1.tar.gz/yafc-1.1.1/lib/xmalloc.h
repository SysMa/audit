/* $Id: xmalloc.h,v 1.4 2003/07/12 10:25:41 mhe Exp $
 *
 * xmalloc.h -- wrapper for malloc etc.
 *
 * Yet Another FTP Client
 * Copyright (C) 1998-2001, Martin Hedenfalk <mhe@stacken.kth.se>
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version. See COPYING for more details.
 */

#ifndef XMALLOC_H_INCLUDED
#define XMALLOC_H_INCLUDED

#include <stdio.h>

void *xmalloc(size_t size);
void *xrealloc(void *ptr, size_t size);
char *xstrdup(const char *s);
char *xstrndup(const char *s, size_t n);
char *xstrncpy(char *dest, const char *src, size_t n);
int xstrcmp(const char *a, const char *b);

#endif


# -*- coding: utf-8 -*-

DEVELOPERS = {
    'alo'          : "Alvaro Lopez Ortega  <alvaro@octality.com>",
    'aperez'       : "Antonio Perez  <aperez@skarcha.com>",
    'ion'          : "Jonathan Hernandez  <ion@suavizado.com>",
    'taher'        : "Taher Shihadeh  <taher@unixwars.com>",
    'robertounbit' : "Roberto De Ioris <roberto@unbit.it>",
    'gefire'       : "李炅 <lijiong1986@126.com>",
    'skinkie'      : "Stefan de Konink <stefan@konink.de>",
    'adefacc'      : "A.D.F. <adefacc@tin.it>",
    'cesar'        : "Cesar Fernandez Gago <cesar@pk2.org>",
    'sberlotto'    : "Sérgio H. Berlotto Jr <sergio.berlotto@gmail.com>",
    'pigmej'       : "Jędrzej Nowak <me@pigmej.eu>",
    'rodrigo'      : "Rodrigo Fernandez-Vizarra <rfvizarra@gmail.com>"
}
